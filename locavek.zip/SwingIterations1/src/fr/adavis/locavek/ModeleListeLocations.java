package fr.adavis.locavek;

import java.util.List;

import javax.swing.JButton;
import javax.swing.table.AbstractTableModel;

public class ModeleListeLocations extends AbstractTableModel {

private static final long serialVersionUID = 1L;
	
	private List<Location> locations = ModeleLocavek.getModele().getLocations() ;
	private final String[] entetes = {"Numero","Vehicule","Client","Date de départ",
			"Date de retour","Retour"} ;
	
	public ModeleListeLocations() {
		super() ;
		System.out.println("ModeleListeLocations::ModeleListeLocations()") ;
	}

	@Override
	public int getRowCount() {
		System.out.println("ModeleListeLocations::getRowCount()") ;
		return this.locations.size() ;
	}

	@Override
	public int getColumnCount() {
		System.out.println("ModeleListeLocations::getColumnCount()") ;
		return this.entetes.length ;
	}
	
	@Override
	public String getColumnName(int columnIndex) {
		System.out.println("ModeleListeLocations::getColumnName()") ;
		return this.entetes[columnIndex] ;
	}

	public Class getColumnClass(int column){
		switch(column){
			case 0:
				return Integer.class;
			case 1:
				return Vehicule.class;
			case 2:
				return Client.class;
			case 3:
				return DateFR.class;
			case 4:
				return DateFR.class;
			case 5:
				return JButton.class;
			default:
				return Object.class;
		}
	}
	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		System.out.println("ModeleListeLocations::getValueAt("+rowIndex+","+columnIndex+")") ;
		
		switch(columnIndex)
		{		
		case 0 :
			return new Integer(this.locations.get(rowIndex).getNumero()) ;
		case 1 : 
			return this.locations.get(rowIndex).getVehicule() ;
		case 2 : 
			return this.locations.get(rowIndex).getClient() ;
		case 3 : 
			return this.locations.get(rowIndex).getDateDepart() ;
		case 4:
			return this.locations.get(rowIndex).getDateRetourEffective() ;
	
		default : 
			return null ;
		}
		
	}
	
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		if(columnIndex == 5 ) {
			return true ;
		}
		else{
			return false;
		}
	}
	
	public void actualiser(){
		System.out.println("ModeleListeLocations::actualiser()") ;
		this.fireTableDataChanged();
	}
	
	public Location getLocation(int indiceLigne) {
		return this.locations.get(indiceLigne) ;
	}
	
}
