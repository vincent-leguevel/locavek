package fr.adavis.locavek;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

/** Contrôleur dédié à la vue "Authentification"
 * @author xilim
 *
 */
public class ControleurAuthentification implements ActionListener {
	
	private VueAuthentification vue ;
	
	// Votre code ici
	private ModeleLocavek modele = ModeleLocavek.getModele() ;
	
	private EtatTentativeConnexion etatTentativeConnexion = EtatTentativeConnexion.ABANDON ;
	
	/** Constructeur
	 * @param vue La vue associée
	 */
	public ControleurAuthentification(VueAuthentification vue){
		super() ;
		System.out.println("ControleurAuthentification::ControleurAuthentification()") ;
		this.vue = vue ;
		this.enregistrerEcouteur() ;
	}
	
	/** Enregistrer le contrôleur comme écouteur des deux boutons
	 * 
	 */
	private void enregistrerEcouteur(){
		System.out.println("ControleurAuthentification::enregistrerEcouteur()") ;
		// Votre code ici
		this.vue.getbConnecter().addActionListener(this) ;
		this.vue.getbAnnuler().addActionListener(this) ;
	}
	
	/** Obtenir le résultat de la tentative de connexion
	 * @return Résultat de la tentative de connexion
	 */
	public EtatTentativeConnexion getEtatTentativeConnexion(){
		System.out.println("ControleurAuthentification::getEtatTentativeConnexion()") ;
		return this.etatTentativeConnexion ;
	}

	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("ControleurAuthentification::actionPerformed()") ;
		Object sourceEvt = e.getSource() ;
		// Votre code ici
		if(e.getSource() == this.vue.getbConnecter()) {
			String login = (this.vue.getTfLogin().getText()) ; 
			String mdp = (this.vue.getPfMDP().getText()) ;
			if(this.modele.getUtilisateur(login,mdp) != null) {
				JOptionPane.showMessageDialog(this.vue, "Bienvenue " + login + ".", "Authentification réussie", 
						JOptionPane.INFORMATION_MESSAGE) ;
				this.vue.dispose();
				etatTentativeConnexion = EtatTentativeConnexion.OK ;
				
			}
			else{
				JOptionPane.showMessageDialog(this.vue, "Authentification échouée, login ou mot de passe inconnu.", "Authentification échouée", 
						JOptionPane.WARNING_MESSAGE) ;
				this.vue.initialiser() ;
			}
		}
		else if(e.getSource() == this.vue.getbAnnuler()) {
			this.vue.dispose() ;
		}
	}
	
}
