package fr.adavis.locavek;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/** Vue relative au cas d'utilisation "Enregistrer une nouvelle location"
 * 
 * @author xilim
 *
 */
public class VueNouvelleLocation extends JDialog {

	private static final long serialVersionUID = 1L;
	
	private ControleurNouvelleLocation controleur ;
	
	// Votre code ici
	private ModeleLocavek modele = ModeleLocavek.getModele() ;
	
	private JComboBox<Client> cbClients = new JComboBox<Client>() ;
	private JComboBox<Vehicule> cbVehicules = new JComboBox<Vehicule>() ;
	
	private JTextField tfDateRetourPrevue = new JTextField() ;
	
	private JButton bEnregistrer = new JButton("Enregistrer") ;
	private JButton bAnnuler = new JButton("Annuler") ;
	
	private ArrayList<Vehicule> vehicules = new ArrayList<Vehicule>() ;
	
	/** Constructeur
	 * @param vueParente La vue principale de l'application
	 */
	public VueNouvelleLocation(JFrame vueParente) {
		super(vueParente,"Nouvelle location",true);
		System.out.println("VueNouvelleLocation::VueNouvelleLocation()") ;
		this.creerInterfaceUtilisateur() ;
		this.controleur = new ControleurNouvelleLocation(this) ;
		this.initialiser();
		this.pack();
		this.setLocationRelativeTo(vueParente) ;
		this.setResizable(false) ;
		this.setVisible(true) ;
	}

	public JComboBox<Client> getCbClients() {
		return cbClients;
	}
	
	public JComboBox<Vehicule> getCbVehicules() {
		return cbVehicules;
	}

	public JTextField getTfDateRetourPrevue() {
		return tfDateRetourPrevue;
	}

	public JButton getbEnregistrer() {
		return bEnregistrer;
	}

	public JButton getbAnnuler() {
		return bAnnuler;
	}

	/** Créer l'interface utilisateur
	 * 
	 */
	private void creerInterfaceUtilisateur(){
		System.out.println("VueNouvelleLocation::creerInterfaceUtilisateur()") ;
		
		// Votre code ici
		
		List<Client> lesClients = modele.getClients() ;
		for(int i=0 ; i < lesClients.size(); i++) {
			cbClients.addItem(lesClients.get(i));
		}
		
		List<Vehicule> lesVehicules = modele.getVehiculesDisponibles() ;
		for(int i=0 ; i < lesVehicules.size() ; i++){
			cbVehicules.addItem(lesVehicules.get(i));
		}		
		
		Container conteneur = this.getContentPane() ;
		
		Box boxPrincipale = Box.createVerticalBox() ;
		Box boxClient = Box.createHorizontalBox() ;
		Box boxVehicule = Box.createHorizontalBox() ;
		Box boxDateRetour = Box.createHorizontalBox() ;
		Box boxLigne = Box.createHorizontalBox() ;
		Box boxActions = Box.createHorizontalBox() ;
		
		boxClient.add(Box.createHorizontalStrut(5)) ;
		boxClient.add(new JLabel("Client : ")) ;
		boxClient.add(cbClients) ;
		boxClient.add(Box.createHorizontalStrut(5)) ;
		
		boxVehicule.add(Box.createHorizontalStrut(5)) ;
		boxVehicule.add(new JLabel("Véhicule : ")) ;
		boxVehicule.add(cbVehicules) ;
		boxVehicule.add(Box.createHorizontalStrut(5)) ;
		
		boxDateRetour.add(Box.createHorizontalStrut(5)) ;
		boxDateRetour.add(new JLabel("Date de retour : ")) ;
		boxDateRetour.add(tfDateRetourPrevue) ; ;
		boxDateRetour.add(Box.createHorizontalStrut(5)) ;
		
		boxLigne.add(Box.createHorizontalStrut(5)) ;
		boxLigne.add(new JSeparator()) ;
		boxLigne.add(Box.createHorizontalStrut(5)) ;
		
		boxActions.add(Box.createHorizontalStrut(5)) ;
		boxActions.add(this.bEnregistrer) ;
		boxActions.add(Box.createHorizontalStrut(5)) ;
		boxActions.add(this.bAnnuler) ;
		boxActions.add(Box.createHorizontalStrut(5)) ;
		
		boxPrincipale.add(Box.createVerticalStrut(5)) ;
		boxPrincipale.add(boxClient) ;
		boxPrincipale.add(Box.createVerticalStrut(5)) ;
		boxPrincipale.add(boxVehicule) ;
		boxPrincipale.add(Box.createVerticalStrut(5)) ;
		boxPrincipale.add(boxDateRetour) ;
		boxPrincipale.add(Box.createVerticalStrut(5)) ;
		boxPrincipale.add(boxLigne) ;
		boxPrincipale.add(Box.createVerticalStrut(5)) ;
		boxPrincipale.add(boxActions) ;
		boxPrincipale.add(Box.createVerticalStrut(5)) ;
		
		conteneur.add(boxPrincipale) ;
		
		Dimension dimensionBouton = this.bEnregistrer.getPreferredSize() ;
		
		this.bAnnuler.setPreferredSize(dimensionBouton) ;
		this.bAnnuler.setMaximumSize(dimensionBouton) ;
		this.bAnnuler.setMinimumSize(dimensionBouton) ;		
		
	}
	
	
	/** Initialiser les champs (liste des clients, liste des véhicules et date de retour prévue
	 * 
	 */
	private void initialiser(){
		System.out.println("VueNouvelleLocation::initialiser()") ;
		
		// Votre code ici
		DateFR aujourdhui = new DateFR() ;
		this.tfDateRetourPrevue.setText(aujourdhui.toString());
	}
}
