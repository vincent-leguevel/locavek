package fr.adavis.locavek;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.* ;

import javax.swing.JOptionPane;

/** Contrôleur associé à la vue principale de l'application
 * @author xilim
 *
 */
public class ControleurLocavek implements ActionListener {

	private VueLocavek vue ;
	
	/** Constructeur
	 * @param vue La vue principale de l'application
	 */
	public ControleurLocavek(VueLocavek vue) {
		super();
		System.out.println("ControleurLocavek::ControleurLocavek()") ;
		this.vue = vue ;
		this.enregistrerEcouteur();
	}
	
	public VueLocavek getVuePrincipale() {
		return this.vue ;
	}

	public void setVuePrincipales(VueLocavek vue) {
		this.vue = vue ;
	}
	
	/** Enregistrer le contrôleur comme écouteur des items de menu
	 * 
	 */
	private void enregistrerEcouteur(){
		System.out.println("ControleurLocavek::enregistrerEcouteur()") ;
		// Votre code ici
		this.vue.getItemQuitter().addActionListener(this);
		this.vue.getItemConnecter().addActionListener(this) ;
		this.vue.getItemDeconnecter().addActionListener(this);
		this.vue.getItemEnregistrerClient().addActionListener(this);
		this.vue.getItemEnregistrerLocation().addActionListener(this) ;
		this.vue.getItemVisualiserLocations().addActionListener(this) ;
		this.vue.getItemVisualiserClients().addActionListener(this) ;
		this.vue.getItemVisualiserVehicules().addActionListener(this) ;
		this.vue.getItemVisualiserLocations().addActionListener(this);
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("ControleurLocavek::actionPerformed()") ;
		Object sourceEvt = e.getSource() ;
		
		// Votre code ici
		if(sourceEvt == this.vue.getItemQuitter()) {
			System.exit(0) ;
		}
		else if(sourceEvt == this.vue.getItemConnecter()) {
			VueAuthentification authentification = new VueAuthentification(vue) ;
			if(authentification.getEtatTentativeConnexion() == EtatTentativeConnexion.OK) {
				this.vue.setMenusConnecte() ;
			}
		}
		else if(sourceEvt == this.vue.getItemDeconnecter()) {
			this.vue.setMenusDeconnecte() ;
		}
		else if(sourceEvt == this.vue.getItemEnregistrerClient()) {
			VueNouveauClient nouveauClient = new VueNouveauClient(vue) ;
			vue.getVueListeClients().getModeleTabClients().actualiser() ;
			vue.changerVue("ListeClients") ;
			
		}
		else if(sourceEvt == this.vue.getItemEnregistrerLocation()) {
			VueNouvelleLocation nouvelleLocation = new VueNouvelleLocation(vue) ;
			vue.getVueListeLocations().getModeleTabLocations().actualiser() ;
			vue.changerVue("ListeLocations");
		}
		else if(sourceEvt == this.vue.getItemVisualiserClients()){
			System.out.println("ControleurLocavek::VueListeClients()") ;		
			vue.changerVue("ListeClients") ;
		}
		else if(sourceEvt == this.vue.getItemVisualiserVehicules()){
			System.out.println("ControleurLocavek::VueListeVehicules()") ;
			vue.changerVue("ListeVehicules") ;
		}
		else if(sourceEvt == this.vue.getItemVisualiserLocations()) {
			System.out.println("ControleurLocavek::VueListeLocations()") ;
			vue.changerVue("ListeLocations") ;
			
		}
	}
		
	
}
