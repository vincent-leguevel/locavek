package fr.adavis.locavek;

import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/** Vue associée au cas d'utilisation "Visualiser la liste des clients"
 * @author xilim
 *
 */
public class VueListeClients extends JPanel {


	private static final long serialVersionUID = 1L;
	
	private ModeleListeClients modeleTabClients = new ModeleListeClients() ;
	private JTable tabClients ;
	
	/** Constructeur
	 * 
	 */
	public VueListeClients(){
		super() ;
		System.out.println("VueListeClients::VueListeClients()") ;
		this.creerInterfaceUtilisateur() ;
	}
	
	/** Agencer les composants graphiques
	 * 
	 */
	private void creerInterfaceUtilisateur(){
		System.out.println("VueListeClients::creerInterfaceUtilisateur()") ;
		Box boxPrincipale = Box.createVerticalBox() ;
		Box boxEtiquette = Box.createHorizontalBox() ;
		Box boxTableau = Box.createHorizontalBox() ;
		
		// Votre code ici
		
		JLabel labelClient = new JLabel("Liste des clients") ;
		
		this.tabClients = new JTable(modeleTabClients) ;
		this.tabClients.setRowHeight(30) ;
		JScrollPane spClients = new JScrollPane(this.tabClients) ;
		spClients.setPreferredSize(new Dimension(1090,420)) ;
		
		boxEtiquette.add(labelClient) ;
		boxTableau.add(spClients) ;
		
		boxPrincipale.add(boxEtiquette) ;
		boxPrincipale.add(boxTableau) ;	
		
		this.add(boxPrincipale) ;
		this.setVisible(true) ;
		this.modeleTabClients.actualiser() ;
		
	}
	
	public JTable getTabClients() {
		return tabClients;
	}

	public ModeleListeClients getModeleTabClients() {
		return modeleTabClients;
	}

	
}
