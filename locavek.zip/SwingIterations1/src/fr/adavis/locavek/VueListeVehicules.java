package fr.adavis.locavek;

import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class VueListeVehicules extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private ModeleListeVehicules modeleTabVehicules = new ModeleListeVehicules()  ;
	private JTable tabVehicules ;
	private RenduCelluleVehicule renduVehicules = new RenduCelluleVehicule() ;
	
	/** Constructeur
	 * 
	 */
	public VueListeVehicules(){
		super() ;
		System.out.println("VueListeVehicules::VueListeVehicules()") ;
		this.creerInterfaceUtilisateur() ;
	}
	
	/** Agencer les composants graphiques
	 * 
	 */
	private void creerInterfaceUtilisateur(){
		System.out.println("VueListeVehicules::creerInterfaceUtilisateur()") ;
		Box boxPrincipale = Box.createVerticalBox() ;
		Box boxEtiquette = Box.createHorizontalBox() ;
		Box boxTableau = Box.createHorizontalBox() ;
		
		// Votre code ici
		
		JLabel labelVehicule = new JLabel("Liste des véhicules") ;
		
		this.tabVehicules = new JTable(modeleTabVehicules) ;
		this.tabVehicules.setRowHeight(30) ;
		this.tabVehicules.setDefaultRenderer(Object.class, renduVehicules) ;
		JScrollPane spVehicules = new JScrollPane(this.tabVehicules) ;
		spVehicules.setPreferredSize(new Dimension(1090,350)) ;
		
		boxEtiquette.add(labelVehicule) ;
		boxTableau.add(spVehicules) ;
		
		boxPrincipale.add(boxEtiquette) ;
		boxPrincipale.add(boxTableau) ;
		
		this.add(boxPrincipale) ;
		
	}
	
	public JTable getTabVehicules() {
		return tabVehicules;
	}

	public ModeleListeVehicules getModeleTabVehicules() {
		return modeleTabVehicules;
	}
	
}
