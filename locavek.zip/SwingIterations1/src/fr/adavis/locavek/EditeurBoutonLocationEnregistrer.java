package fr.adavis.locavek;

import java.awt.Component;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTable;

public class EditeurBoutonLocationEnregistrer extends DefaultCellEditor {

	protected JButton bouton;
	private boolean isPushed;
	private ControleurBoutonLocationEnregistrer controleur;
	private static JCheckBox box = new JCheckBox();
	private VueListeLocations vue;
	
	public EditeurBoutonLocationEnregistrer(VueListeLocations vue){
		super(box);
		System.out.println("EditeurBoutonLocationEnregistrer::EditeurBoutonLocationEnregistrer");
		controleur = new ControleurBoutonLocationEnregistrer(this);
		bouton = new JButton("Enregistrer");
		this.vue = vue;
	}
	
	public Component getTableCellEditorComponent(JTable table,Object objet, boolean isPushed,int row, int column){
		System.out.println("EditeurBoutonLocationEnregistrer::getTableCellEditorComponent");
		if(column == 5){
			this.bouton.setText("Enregistrer");
		}
		return bouton;
	}
}
