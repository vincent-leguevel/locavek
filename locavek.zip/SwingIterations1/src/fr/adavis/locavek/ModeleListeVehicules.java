package fr.adavis.locavek;

import java.util.List;

import javax.swing.table.AbstractTableModel;

public class ModeleListeVehicules extends AbstractTableModel {

	private static final long serialVersionUID = 1L;
	
	private List<Vehicule> vehicules = ModeleLocavek.getModele().getVehicules() ;
	private final String[] entetes = {"Immatriculation","Modèle","Année","Compteur","Situation"} ;
	
	public ModeleListeVehicules() {
		super() ;
		System.out.println("ModeleListeVehicules::ModeleListeVehicules()") ;
	}

	@Override
	public int getRowCount() {
		System.out.println("ModeleListeVehicules::getRowCount()") ;
		// Votre code ici
		return this.vehicules.size() ;
	}

	@Override
	public int getColumnCount() {
		System.out.println("ModeleListeVehicules::getColumnCount()") ;
		// Votre code ici
		return this.entetes.length ;
	}
	
	@Override
	public String getColumnName(int columnIndex) {
		System.out.println("ModeleListeVehicules::getColumnName()") ;
		// Votre code ici
		return this.entetes[columnIndex] ;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		System.out.println("ModeleListeVehicules::getValueAt("+rowIndex+","+columnIndex+")") ;
		// Votre code ici
		
		switch(columnIndex)
		{		
		case 0 :
			return new String(this.vehicules.get(rowIndex).getImmatriculation()) ;
		case 1 : 
			return this.vehicules.get(rowIndex).getModele() ;
		case 2 : 
			return this.vehicules.get(rowIndex).getAnnee() ;
		case 3 : 
			return this.vehicules.get(rowIndex).getCompteur() ;
		case 4 :
			if(this.vehicules.get(rowIndex).getSituation() == 1){
				return "Disponible" ;
			}
			if(this.vehicules.get(rowIndex).getSituation() == 2){
				return "Loué" ;
			}
			if(this.vehicules.get(rowIndex).getSituation() == 3){
				return "Immobilisé" ;
			}
		default : 
			return null ;
		}
		
	}
	
	public void actualiser(){
		System.out.println("ModeleListeVehicules::actualiser()") ;
		this.fireTableDataChanged();
	}
	
	public int getSituation(int indiceLigne){
		return vehicules.get(indiceLigne).getSituation() ;
	}

}
