package fr.adavis.locavek;

import java.awt.Component;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

public class RenduBoutonLocation extends JButton implements TableCellRenderer {

	
	@Override
	public Component getTableCellRendererComponent(JTable table, Object value,
			boolean isSelected, boolean hasFocus, int row, int column) {
		
		
		Location location = ((ModeleListeLocations) table.getModel()).getLocation(row) ;

		if(column == 5){
		
			if(location.estEnCours()){
				this.setEnabled(true);
			}
			else if(location.estTerminee()){
				this.setEnabled(false);
			}
			return this;
		}
		
		return null;
	}

}
