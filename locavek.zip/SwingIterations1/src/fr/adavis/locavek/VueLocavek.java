package fr.adavis.locavek;

import java.awt.CardLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/** Vue principale de l'application
 * 
 * @author xilim
 *
 */
public class VueLocavek extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	private ControleurLocavek controleur ;
		
	private JMenuItem itemConnecter  = new JMenuItem("Se connecter") ;
	private JMenuItem itemDeconnecter  = new JMenuItem("Se déconnecter") ;
	private JMenuItem itemQuitter = new JMenuItem("Quitter") ;
	private JMenuItem itemVisualiserLocations = new JMenuItem("Liste des locations") ;
	private JMenuItem itemEnregistrerLocation = new JMenuItem("Nouvelle location") ;
	private JMenuItem itemVisualiserClients = new JMenuItem("Liste des clients") ;
	private JMenuItem itemEnregistrerClient = new JMenuItem("Nouveau client") ;
	private JMenuItem itemVisualiserVehicules = new JMenuItem("Liste des véhicules") ;
	
	private JMenu menuFichier = new JMenu("Fichier") ;
	private JMenu menuLocations = new JMenu("Locations") ;
	private JMenu menuVehicules = new JMenu("Véhicules") ;
	private JMenu menuClients = new JMenu("Clients") ;
	private CardLayout clPanneaux = new CardLayout(5,5) ;
	private Container conteneur ;

	private VueAccueil accueil = new VueAccueil() ;
	private VueListeClients listeClients = new VueListeClients() ;
	private VueListeVehicules listeVehicules = new VueListeVehicules() ;
	private VueListeLocations listeLocations = new VueListeLocations() ;
	

	/** Constructeur
	 * 
	 */
	public VueLocavek() {
		super();
		System.out.println("VuePrincipale::VuePrincipale()") ;
		
		this.setTitle("Locavek") ;
		this.setSize(1300,500) ; 
		this.setLocationRelativeTo(null) ;
		this.setDefaultCloseOperation(EXIT_ON_CLOSE) ;
		
		this.creerBarreMenus() ;
		this.setMenusDeconnecte();
		this.setVisible(true) ;
		
		this.controleur = new ControleurLocavek(this) ;
		
		conteneur = this.getContentPane() ;
		conteneur.setLayout(clPanneaux) ;		
		
		conteneur.add(accueil, "Accueil");
		conteneur.add(listeClients, "ListeClients") ;
		conteneur.add(listeVehicules, "ListeVehicules") ;
		conteneur.add(listeLocations, "ListeLocations") ;
		
		clPanneaux.show(conteneur, "Accueil");
		
	}
	
	public void changerVue(String vue) {
		System.out.println("VuePrincipale::changerVue()") ;
		clPanneaux.show(conteneur, vue)	;
		
	}
	
	public ControleurLocavek getControleur() {
		return this.controleur;
	}

	public JMenuItem getItemConnecter() {
		return itemConnecter;
	}
	
	public JMenuItem getItemQuitter() {
		return itemQuitter;
	}

	public JMenuItem getItemVisualiserLocations() {
		return itemVisualiserLocations;
	}

	public JMenuItem getItemEnregistrerLocation() {
		return itemEnregistrerLocation;
	}

	public JMenuItem getItemVisualiserClients() {
		return itemVisualiserClients;
	}

	public JMenuItem getItemEnregistrerClient() {
		return itemEnregistrerClient;
	}

	public JMenuItem getItemVisualiserVehicules() {
		return itemVisualiserVehicules;
	}

	public JMenuItem getItemDeconnecter() {
		return itemDeconnecter;
	}
	
	public VueListeClients getVueListeClients() {
		return this.listeClients ;
	}
	
	public VueListeVehicules getVueListeVehicules() {
		return this.listeVehicules ;
	}
	
	public VueListeLocations getVueListeLocations() {
		return this.listeLocations ;
	}
	
	/** Positionner les menus et les items de menu pour l'état "Connecté"
	 * 
	 */
	public void setMenusConnecte(){
		System.out.println("VuePrincipale::setMenusConnecte()") ;
		// Votre code ici
		itemConnecter.setEnabled(false);
		itemQuitter.setEnabled(true);
		itemDeconnecter.setEnabled(true) ;
		menuLocations.setEnabled(true) ;
		menuClients.setEnabled(true);
		menuVehicules.setEnabled(true);
	}
	
	/** Positionner les menus et les items de menu pour l'état "Déonnecté"
	 * 
	 */
	public void setMenusDeconnecte(){
		System.out.println("VuePrincipale::setMenusDeconnecte()") ;
		// Votre code ici
		itemConnecter.setEnabled(true);
		itemQuitter.setEnabled(true);
		itemDeconnecter.setEnabled(false) ;
		menuLocations.setEnabled(false) ;
		menuClients.setEnabled(false);
		menuVehicules.setEnabled(false);
	}

	/** Créer la barre de menus
	 * 
	 */
	private void creerBarreMenus(){
		System.out.println("VuePrincipale::creerBarreMenus()") ;
		JMenuBar barreMenus = new JMenuBar() ;
		
		menuFichier.add(this.itemConnecter) ;
		menuFichier.add(this.itemDeconnecter) ;
		menuFichier.addSeparator() ;
		menuFichier.add(this.itemQuitter) ;

		menuLocations.add(this.itemVisualiserLocations) ;
		menuLocations.add(this.itemEnregistrerLocation) ;
		
		menuClients.add(this.itemVisualiserClients) ;
		menuClients.add(this.itemEnregistrerClient) ;
		
		menuVehicules.add(this.itemVisualiserVehicules) ;
		
		barreMenus.add(menuFichier) ;
		barreMenus.add(menuLocations) ;
		barreMenus.add(menuClients) ;
		barreMenus.add(menuVehicules) ;
		
		this.setJMenuBar(barreMenus) ;
		
	}

}
