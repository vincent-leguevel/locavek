package fr.adavis.locavek;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTable;

public class ControleurBoutonLocationEnregistrer implements ActionListener {

	private ModeleLocavek modele = ModeleLocavek.getModele();
	private int row;
	private int column;
	private JTable table;
	private EditeurBoutonLocationEnregistrer editeur;
	
	public ControleurBoutonLocationEnregistrer(EditeurBoutonLocationEnregistrer editeur){
		this.editeur = editeur;
	}

	
	public ModeleLocavek getModele() {
		return modele;
	}


	public void setModele(ModeleLocavek modele) {
		this.modele = modele;
	}


	public void setRow(int row) {
		this.row = row;
	}


	public void setColumn(int column) {
		this.column = column;
	}


	public void setTable(JTable table) {
		this.table = table;
	}
	
	public void setEditeur(EditeurBoutonLocationEnregistrer editeur){
		this.editeur = editeur;
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	


}
