package fr.adavis.locavek;

import java.awt.Dimension;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class VueListeLocations extends JPanel {
	
	private static final long serialVersionUID = 1L;
	
	private ModeleListeLocations modeleTabLocations = new ModeleListeLocations()  ;
	private JTable tabLocations ;
	private RenduCelluleLocation renduLocations = new RenduCelluleLocation() ;
	private RenduBoutonLocation renduBouton = new RenduBoutonLocation() ;
	private EditeurBoutonLocationEnregistrer editeur;
	
	public VueListeLocations(){
		super() ;
		System.out.println("VueListeVehicules::VueListeVehicules()") ;
		this.creerInterfaceUtilisateur() ;
	}

	private void creerInterfaceUtilisateur(){
		System.out.println("VueListeVehicules::creerInterfaceUtilisateur()") ;
		Box boxPrincipale = Box.createVerticalBox() ;
		Box boxEtiquette = Box.createHorizontalBox() ;
		Box boxTableau = Box.createHorizontalBox() ;
		
		JLabel labelLocations = new JLabel("Liste des locations") ;
		
		this.tabLocations = new JTable(modeleTabLocations) ;
		this.tabLocations.setRowHeight(30) ;
		appliquerRendu();
		appliquerEditeur();
		JScrollPane spLocations = new JScrollPane(this.tabLocations) ;
		spLocations.setPreferredSize(new Dimension(1090,350)) ;
		
		boxEtiquette.add(labelLocations) ;
		boxTableau.add(spLocations) ;
		
		boxPrincipale.add(boxEtiquette) ;
		boxPrincipale.add(boxTableau) ;
		
		this.add(boxPrincipale) ;
	}
	
	public JTable getTabVehicules() {
		return tabLocations ;
	}

	public ModeleListeLocations getModeleTabLocations() {
		return modeleTabLocations ;
	}
	
	public void appliquerRendu(){
		System.out.println("VueListeVehicules::appliquerRendu()") ;
		this.tabLocations.setDefaultRenderer(Object.class, renduLocations) ;
		
		if(tabLocations.getColumnClass(5) == JButton.class){		
			this.tabLocations.setDefaultRenderer(JButton.class, renduBouton);
		}
			
		
	}
	
	public void appliquerEditeur(){
		System.out.println("VueListeVehicules::appliquerEditeur()") ;
		this.tabLocations.setDefaultEditor(Object.class, new EditeurBoutonLocationEnregistrer(this));
	}
	
}
